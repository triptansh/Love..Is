'use client';

import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface AnimatedTextProps {
  text: string;
  className?: string;
  as?: 'h1' | 'h2' | 'h3' | 'p' | 'span';
  delay?: number;
  stagger?: boolean;
}

export function AnimatedText({
  text,
  className,
  as: Tag = 'p',
  delay = 0,
  stagger = false,
}: AnimatedTextProps) {
  if (!stagger) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay, ease: [0.25, 0.46, 0.45, 0.94] }}
      >
        <Tag className={className}>{text}</Tag>
      </motion.div>
    );
  }

  const words = text.split(' ');
  return (
    <Tag className={cn('overflow-hidden', className)}>
      {words.map((word, i) => (
        <motion.span
          key={i}
          className="inline-block mr-[0.25em]"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            duration: 0.7,
            delay: delay + i * 0.06,
            ease: [0.25, 0.46, 0.45, 0.94],
          }}
        >
          {word}
        </motion.span>
      ))}
    </Tag>
  );
}

// ── Line-by-line animated poem text ──
interface AnimatedLinesProps {
  lines: string[];
  className?: string;
  lineClassName?: string;
  baseDelay?: number;
  staggerDelay?: number;
}

export function AnimatedLines({
  lines,
  className,
  lineClassName,
  baseDelay = 0.1,
  staggerDelay = 0.18,
}: AnimatedLinesProps) {
  return (
    <div className={className}>
      {lines.map((line, i) => (
        <motion.p
          key={i}
          className={lineClassName}
          initial={{ opacity: 0, x: -16, filter: 'blur(4px)' }}
          animate={{ opacity: 1, x: 0, filter: 'blur(0px)' }}
          transition={{
            duration: 0.85,
            delay: baseDelay + i * staggerDelay,
            ease: [0.25, 0.46, 0.45, 0.94],
          }}
        >
          {line}
        </motion.p>
      ))}
    </div>
  );
}
