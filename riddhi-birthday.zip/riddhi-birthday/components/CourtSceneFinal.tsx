'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MovingButton } from './MovingButton';
import { ConfettiAnimation } from './ConfettiAnimation';

interface CourtSceneFinalProps {
  title: string;
  lines: string[];
}

export function CourtSceneFinal({ title, lines }: CourtSceneFinalProps) {
  const [verdict, setVerdict]   = useState<'forgiven' | 'escaped' | null>(null);
  const [showRetry, setShowRetry] = useState(false);

  const handleForgive = () => {
    setVerdict('forgiven');
  };

  const handleEscape = () => {
    setVerdict('escaped');
    // Auto return after 3s
    setTimeout(() => {
      setVerdict(null);
      setShowRetry(true);
    }, 3000);
  };

  return (
    <div className="flex flex-col items-center gap-6 w-full max-w-lg text-center">
      <ConfettiAnimation trigger={verdict === 'forgiven'} loop />

      <AnimatePresence mode="wait">
        {verdict === null && (
          <motion.div
            key="court"
            className="flex flex-col items-center gap-5"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {/* Gavel icon */}
            <motion.span
              className="text-5xl sm:text-6xl"
              animate={{ rotate: [0, -15, 0, 15, 0] }}
              transition={{ duration: 2.5, repeat: Infinity, repeatDelay: 1.5 }}
            >
              ⚖️
            </motion.span>

            <h2 className="font-display text-rose-deep text-3xl sm:text-4xl leading-snug">
              {title}
            </h2>

            <div className="deco-line" />

            <div className="glass-card px-6 sm:px-8 py-5 sm:py-6">
              {lines.map((line, i) => (
                <motion.p
                  key={i}
                  className="font-serif text-lg sm:text-xl italic text-text-mid leading-relaxed"
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + i * 0.2 }}
                >
                  {line}
                </motion.p>
              ))}
            </div>

            {/* Buttons */}
            <div className="flex flex-col sm:flex-row items-center gap-4 mt-2 w-full">
              {/* YES — big prominent */}
              <motion.button
                onClick={(e) => { e.stopPropagation(); handleForgive(); }}
                className="px-7 py-4 rounded-full bg-gradient-to-br from-rose to-rose-deep
                           text-white font-display text-lg sm:text-xl shadow-rose
                           btn-ripple cursor-pointer border-none w-full sm:w-auto"
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                whileHover={{ scale: 1.05, y: -3, boxShadow: '0 14px 40px rgba(196,104,122,0.5)' }}
                whileTap={{ scale: 0.95 }}
              >
                Kardiya maaf, Pandit ji 🌷
              </motion.button>

              {/* NO — runs away */}
              <motion.div
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.85 }}
              >
                <MovingButton
                  label="Hum toh aise naa maane, Pandit ji 😏"
                  onEscapeClick={handleEscape}
                  className="px-5 py-3 rounded-full bg-transparent text-rose
                             border border-rose/40 font-body text-base italic
                             cursor-pointer hover:bg-rose/5 transition-colors
                             whitespace-nowrap"
                />
              </motion.div>
            </div>
          </motion.div>
        )}

        {/* Forgiven verdict */}
        {verdict === 'forgiven' && (
          <motion.div
            key="forgiven"
            className="flex flex-col items-center gap-5"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ type: 'spring', stiffness: 260, damping: 20 }}
          >
            <motion.span
              className="text-7xl"
              animate={{ rotate: [0, -10, 10, -10, 0], scale: [1, 1.2, 1] }}
              transition={{ duration: 0.6 }}
            >
              🎉
            </motion.span>
            <h2 className="font-display text-rose-deep text-3xl sm:text-4xl">
              Pandit ji officially lucky hai.
            </h2>
            <p className="font-serif text-xl italic text-text-mid">
              Aur hamesha rahega. 🌹
            </p>
            <div className="deco-line" />
            <p className="font-display text-rose text-2xl">
              Happy Birthday, Kammoji 🌷
            </p>
          </motion.div>
        )}

        {/* Escape — playful redirect page */}
        {verdict === 'escaped' && (
          <motion.div
            key="escaped"
            className="flex flex-col items-center gap-5"
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ type: 'spring', stiffness: 260, damping: 22 }}
          >
            <motion.span
              className="text-6xl"
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 0.5 }}
            >
              😌
            </motion.span>
            <h2 className="font-display text-rose-deep text-2xl sm:text-3xl">
              Nice try, Awasthi ji 😌
            </h2>
            <div className="glass-card px-6 py-4">
              <p className="font-serif text-lg sm:text-xl italic text-text-mid">
                Maafi toh deni hi padegi.
              </p>
            </div>
            <p className="font-body text-mauve text-sm">
              Wapas aa rahi hoon… 3s mein 😏
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
