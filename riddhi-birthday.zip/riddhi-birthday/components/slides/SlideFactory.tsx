'use client';

import type { SlideConfig } from '@/data/slides';
import {
  HeroSlide,
  FloatingNamesSlide,
  PoeticLinesSlide,
  HindiPoemSlide,
  TapRevealSlide,
  ConfettiCelebrationSlide,
  ChoiceButtonsSlide,
  EgoSlide,
} from './SlideRenderers';
import { HeartPopInteraction } from '@/components/HeartPopInteraction';
import { MemoryCardModal } from '@/components/MemoryCardModal';
import { CourtSceneFinal } from '@/components/CourtSceneFinal';

interface SlideFactoryProps {
  slide:     SlideConfig;
  onAdvance: () => void;
}

export function SlideFactory({ slide, onAdvance }: SlideFactoryProps) {
  switch (slide.type) {
    case 'hero':
      return <HeroSlide slide={slide} onAdvance={onAdvance} />;

    case 'floating-names':
      return <FloatingNamesSlide slide={slide} />;

    case 'poetic-lines':
      return <PoeticLinesSlide slide={slide} />;

    case 'hindi-poem':
      return <HindiPoemSlide slide={slide} />;

    case 'tap-reveal':
      return <TapRevealSlide slide={slide} />;

    case 'confetti-celebration':
      return <ConfettiCelebrationSlide slide={slide} />;

    case 'heart-pop':
      return (
        <HeartPopInteraction
          hearts={slide.heartReveals ?? []}
          subtitle={slide.subtitle}
        />
      );

    case 'choice-buttons':
      return <ChoiceButtonsSlide slide={slide} />;

    case 'memory-cards':
      return (
        <MemoryCardModal
          cards={slide.memoryCards ?? []}
          subtitle={slide.subtitle}
        />
      );

    case 'ego-slide':
      return <EgoSlide slide={slide} />;

    case 'court-of-love':
      return (
        <CourtSceneFinal
          title={slide.title ?? ''}
          lines={slide.lines ?? []}
        />
      );

    case 'simple-card':
    default:
      return <PoeticLinesSlide slide={slide} />;
  }
}
