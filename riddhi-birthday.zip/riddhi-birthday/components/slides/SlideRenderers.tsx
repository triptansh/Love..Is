'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AnimatedLines, AnimatedText } from '@/components/AnimatedText';
import { HeartPopInteraction } from '@/components/HeartPopInteraction';
import { MemoryCardModal } from '@/components/MemoryCardModal';
import { CourtSceneFinal } from '@/components/CourtSceneFinal';
import { ConfettiAnimation } from '@/components/ConfettiAnimation';
import type { SlideConfig } from '@/data/slides';

// ── Shared Decorative Components ─────────────────────────
const DecoLine = () => <div className="deco-line" />;

const GlassCard = ({
  children,
  className = '',
}: {
  children: React.ReactNode;
  className?: string;
}) => (
  <div className={`glass-card px-6 sm:px-10 py-7 sm:py-9 max-w-xl w-full ${className}`}>
    {children}
  </div>
);

const SlideNumber = ({ n }: { n: number }) => (
  <motion.span
    className="absolute bottom-14 left-1/2 -translate-x-1/2 slide-number-badge"
    initial={{ opacity: 0 }}
    animate={{ opacity: 0.55 }}
    transition={{ delay: 1 }}
  >
    — {n} —
  </motion.span>
);

// ── Slide 1: Hero ─────────────────────────────────────────
export function HeroSlide({ slide, onAdvance }: { slide: SlideConfig; onAdvance: () => void }) {
  return (
    <div className="flex flex-col items-center gap-6 text-center px-4">
      {/* Floating rose */}
      <motion.span
        className="text-5xl sm:text-7xl"
        animate={{ y: [0, -12, 0], rotate: [-3, 3, -3] }}
        transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
      >
        🌷
      </motion.span>

      <GlassCard className="relative overflow-visible">
        <AnimatedText
          text={slide.title!}
          as="h1"
          className="font-display text-4xl sm:text-6xl text-rose-deep leading-tight"
          delay={0.1}
          stagger
        />
        <DecoLine />
        <AnimatedText
          text={slide.subtitle!}
          as="p"
          className="font-serif text-xl sm:text-2xl italic text-text-mid"
          delay={0.5}
        />
      </GlassCard>

      <motion.button
        onClick={(e) => { e.stopPropagation(); onAdvance(); }}
        className="mt-4 px-8 sm:px-10 py-4 rounded-full bg-gradient-to-br
                   from-rose to-rose-deep text-white font-display text-xl sm:text-2xl
                   shadow-rose btn-ripple cursor-pointer border-none"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.9, type: 'spring', stiffness: 200 }}
        whileHover={{ scale: 1.05, y: -4, boxShadow: '0 14px 40px rgba(196,104,122,0.5)' }}
        whileTap={{ scale: 0.95 }}
      >
        {slide.ctaLabel}
      </motion.button>
    </div>
  );
}

// ── Slide 2: Floating Names ───────────────────────────────
export function FloatingNamesSlide({ slide }: { slide: SlideConfig }) {
  return (
    <div className="flex flex-col items-center gap-3 text-center px-4">
      <GlassCard>
        <div className="flex flex-col gap-4">
          {slide.floatingNames?.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.15 + i * 0.28, duration: 0.8, ease: [0.25, 0.46, 0.45, 0.94] }}
            >
              <div className="flex items-baseline justify-center gap-3 flex-wrap">
                <span className="font-display text-3xl sm:text-5xl text-rose-deep">
                  {item.name}
                </span>
                <span className="font-body text-sm sm:text-base text-mauve italic tracking-wide">
                  — {item.meaning}
                </span>
              </div>
              {i < (slide.floatingNames?.length ?? 0) - 1 && (
                <DecoLine />
              )}
            </motion.div>
          ))}
        </div>
      </GlassCard>

      {slide.caption && (
        <motion.p
          className="font-body italic text-mauve text-sm sm:text-base tracking-wide"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2 }}
        >
          "{slide.caption}"
        </motion.p>
      )}
    </div>
  );
}

// ── Slide Type: Poetic Lines ──────────────────────────────
export function PoeticLinesSlide({ slide }: { slide: SlideConfig }) {
  return (
    <div className="flex flex-col items-center gap-5 text-center px-4 max-w-xl w-full">
      <GlassCard>
        {slide.title && (
          <AnimatedText
            text={slide.title}
            as="h2"
            className="font-display text-2xl sm:text-3xl text-rose-deep mb-4"
            delay={0.1}
          />
        )}
        <AnimatedLines
          lines={slide.lines ?? []}
          lineClassName="font-serif text-lg sm:text-2xl italic text-text-mid leading-relaxed py-1"
          baseDelay={0.15}
          staggerDelay={0.22}
        />
        {slide.caption && (
          <>
            <DecoLine />
            <motion.p
              className="font-body text-mauve text-sm sm:text-base italic"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.15 + (slide.lines?.length ?? 0) * 0.22 + 0.3 }}
            >
              {slide.caption}
            </motion.p>
          </>
        )}
      </GlassCard>
    </div>
  );
}

// ── Slide Type: Hindi Poem ────────────────────────────────
export function HindiPoemSlide({ slide }: { slide: SlideConfig }) {
  return (
    <div className="flex flex-col items-center gap-5 text-center px-4 max-w-xl w-full">
      {/* Decorative top motif */}
      <motion.span
        className="text-2xl"
        initial={{ opacity: 0, scale: 0.6 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.05, type: 'spring' }}
      >
        ✦
      </motion.span>

      <GlassCard>
        {slide.title && (
          <motion.p
            className="font-display text-rose-deep text-xl sm:text-2xl mb-3"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
          >
            {slide.title}
          </motion.p>
        )}
        <AnimatedLines
          lines={slide.lines ?? []}
          lineClassName="font-serif text-lg sm:text-2xl italic text-text-mid leading-relaxed py-0.5"
          baseDelay={0.15}
          staggerDelay={0.2}
        />
        {slide.caption && (
          <>
            <DecoLine />
            <motion.p
              className="font-display text-rose text-base sm:text-lg"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.1 + (slide.lines?.length ?? 0) * 0.2 + 0.4 }}
            >
              {slide.caption}
            </motion.p>
          </>
        )}
      </GlassCard>

      <motion.span
        className="text-2xl"
        initial={{ opacity: 0, scale: 0.6 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.4, type: 'spring' }}
      >
        ✦
      </motion.span>
    </div>
  );
}

// ── Slide 4: Tap Reveal ───────────────────────────────────
export function TapRevealSlide({ slide }: { slide: SlideConfig }) {
  const [revealedCount, setRevealedCount] = useState(0);
  const [started, setStarted]             = useState(false);

  const lines = slide.revealLines ?? [];

  const handleReveal = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!started) { setStarted(true); setRevealedCount(1); return; }
    setRevealedCount((c) => Math.min(c + 1, lines.length));
  };

  return (
    <div
      className="flex flex-col items-center gap-5 text-center px-4 max-w-xl w-full cursor-pointer"
      onClick={handleReveal}
    >
      <GlassCard>
        {!started ? (
          <motion.div
            className="flex flex-col items-center gap-4 py-4"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, type: 'spring' }}
          >
            <span className="text-4xl sm:text-5xl">💌</span>
            <p className="font-display text-rose-deep text-2xl sm:text-3xl">
              {slide.revealCta}
            </p>
            <motion.div
              className="w-10 h-10 rounded-full bg-gradient-to-br from-rose to-rose-deep
                         flex items-center justify-center text-white text-lg shadow-rose"
              animate={{ scale: [1, 1.1, 1] }}
              transition={{ repeat: Infinity, duration: 1.4, ease: 'easeInOut' }}
            >
              ♡
            </motion.div>
          </motion.div>
        ) : (
          <div className="flex flex-col gap-0">
            {lines.map((line, i) => (
              <AnimatePresence key={i}>
                {revealedCount > i && (
                  <motion.div
                    className="flex items-start gap-3 py-3 border-b border-rose/15 last:border-none"
                    initial={{ opacity: 0, x: -22, filter: 'blur(4px)' }}
                    animate={{ opacity: 1, x: 0, filter: 'blur(0px)' }}
                    transition={{ duration: 0.6, ease: [0.25, 0.46, 0.45, 0.94] }}
                  >
                    <span className="text-rose mt-0.5 flex-shrink-0">🌷</span>
                    <p className="font-serif text-lg sm:text-xl italic text-text-mid text-left leading-snug">
                      {line.text}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            ))}
            {revealedCount < lines.length && (
              <motion.p
                className="font-body text-mauve text-xs mt-3 tracking-widest uppercase"
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ repeat: Infinity, duration: 1.5 }}
              >
                tap for more ♡
              </motion.p>
            )}
            {revealedCount === lines.length && (
              <motion.p
                className="font-display text-rose text-lg sm:text-xl mt-3"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
              >
                Every single thing. 🌷
              </motion.p>
            )}
          </div>
        )}
      </GlassCard>
    </div>
  );
}

// ── Slide 7: Confetti Celebration ─────────────────────────
export function ConfettiCelebrationSlide({ slide }: { slide: SlideConfig }) {
  return (
    <div className="flex flex-col items-center gap-5 text-center px-4 max-w-xl w-full">
      <ConfettiAnimation trigger loop />

      <motion.span
        className="text-5xl sm:text-7xl"
        animate={{ rotate: [0, -8, 8, -8, 0], scale: [1, 1.1, 1] }}
        transition={{ duration: 1.2, delay: 0.3, repeat: Infinity, repeatDelay: 3 }}
      >
        🎂
      </motion.span>

      <GlassCard>
        <AnimatedText
          text={slide.title ?? ''}
          as="h2"
          className="font-display text-3xl sm:text-4xl text-rose-deep"
          delay={0.15}
          stagger
        />
        <DecoLine />
        <AnimatedLines
          lines={slide.lines ?? []}
          lineClassName="font-serif text-lg sm:text-2xl italic text-text-mid leading-relaxed"
          baseDelay={0.5}
          staggerDelay={0.25}
        />
      </GlassCard>
    </div>
  );
}

// ── Slide 11: Choice Buttons ──────────────────────────────
export function ChoiceButtonsSlide({ slide }: { slide: SlideConfig }) {
  const [chosen, setChosen]    = useState<number | null>(null);
  const [showResp, setShowResp] = useState(false);

  const handleChoice = (e: React.MouseEvent, i: number) => {
    e.stopPropagation();
    setChosen(i);
    setTimeout(() => setShowResp(true), 350);
  };

  return (
    <div className="flex flex-col items-center gap-5 text-center px-4 max-w-xl w-full">
      <GlassCard>
        <AnimatedText
          text={slide.choiceQuestion ?? ''}
          as="h2"
          className="font-display text-2xl sm:text-3xl text-rose-deep mb-6"
          delay={0.1}
        />

        <div className="grid grid-cols-2 gap-3">
          {slide.choiceOptions?.map((opt, i) => (
            <motion.button
              key={i}
              onClick={(e) => handleChoice(e, i)}
              className={[
                'px-4 py-4 rounded-2xl font-serif text-base sm:text-lg italic text-left',
                'border cursor-pointer transition-all btn-ripple',
                chosen === i
                  ? 'bg-gradient-to-br from-rose to-rose-deep text-white border-transparent shadow-rose'
                  : 'bg-blush-light/70 text-text-mid border-rose/25 hover:border-rose/50 hover:bg-blush',
              ].join(' ')}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + i * 0.1, type: 'spring', stiffness: 200 }}
              whileHover={chosen === null ? { scale: 1.03, y: -2 } : undefined}
              whileTap={{ scale: 0.96 }}
            >
              {opt.label}
            </motion.button>
          ))}
        </div>

        <AnimatePresence>
          {showResp && (
            <motion.p
              className="font-display text-rose-deep text-xl sm:text-2xl mt-6"
              initial={{ opacity: 0, scale: 0.85, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ type: 'spring', stiffness: 260, damping: 20 }}
            >
              {slide.choiceResponse}
            </motion.p>
          )}
        </AnimatePresence>
      </GlassCard>
    </div>
  );
}

// ── Slide 16: Ego Slide ───────────────────────────────────
export function EgoSlide({ slide }: { slide: SlideConfig }) {
  return (
    <div className="flex flex-col items-center gap-6 text-center px-4">
      <GlassCard className="py-10 sm:py-14">
        <motion.div
          initial={{ opacity: 0, scale: 0.7 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ type: 'spring', stiffness: 220, damping: 16, delay: 0.1 }}
        >
          <p className="font-display text-4xl sm:text-6xl text-rose-deep leading-tight handwritten-underline">
            {slide.title}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.7 }}
        >
          <DecoLine />
          <p className="font-serif text-2xl sm:text-3xl italic text-text-mid">
            {slide.caption}
          </p>
        </motion.div>

        <motion.span
          className="text-4xl sm:text-5xl mt-4 block"
          animate={{ rotate: [0, -10, 10, -10, 0] }}
          transition={{ delay: 0.8, duration: 0.6 }}
        >
          👑
        </motion.span>
      </GlassCard>
    </div>
  );
}
