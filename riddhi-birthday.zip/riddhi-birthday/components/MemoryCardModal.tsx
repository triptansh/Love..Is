'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import type { MemoryCard } from '@/data/slides';

interface MemoryCardModalProps {
  cards: MemoryCard[];
  subtitle?: string;
}

interface ModalState {
  open:  boolean;
  card:  MemoryCard | null;
}

export function MemoryCardModal({ cards, subtitle }: MemoryCardModalProps) {
  const [modal, setModal] = useState<ModalState>({ open: false, card: null });

  const openModal = (card: MemoryCard) => {
    setModal({ open: true, card });
  };

  const closeModal = () => {
    setModal({ open: false, card: null });
  };

  return (
    <>
      <div className="flex flex-col items-center gap-5 w-full">
        {subtitle && (
          <motion.p
            className="font-body text-mauve text-sm tracking-widest uppercase"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.15 }}
          >
            {subtitle}
          </motion.p>
        )}

        {/* Cards grid */}
        <div className="grid grid-cols-3 gap-3 sm:gap-5 w-full max-w-sm">
          {cards.map((card, i) => (
            <motion.button
              key={i}
              className="memory-card-hover glass-card flex flex-col items-center
                         justify-center gap-2 p-4 sm:p-5 aspect-[3/4]
                         cursor-pointer border-none text-center"
              onClick={(e) => { e.stopPropagation(); openModal(card); }}
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                delay: 0.1 + i * 0.15,
                duration: 0.6,
                ease: [0.34, 1.56, 0.64, 1],
              }}
              whileHover={{ y: -8, rotate: i % 2 === 0 ? -1.5 : 1.5, scale: 1.04 }}
              whileTap={{ scale: 0.94 }}
              aria-label={`Open ${card.label} memory`}
            >
              {/* Shine */}
              <span
                className="absolute inset-0 rounded-[28px] pointer-events-none"
                style={{
                  background: 'linear-gradient(160deg, rgba(255,255,255,0.45) 0%, transparent 55%)',
                }}
              />

              <span className="text-3xl sm:text-4xl relative z-10">{card.icon}</span>
              <span className="font-display text-rose-deep text-sm sm:text-base relative z-10">
                {card.label}
              </span>
              <span className="font-body text-mauve text-xs mt-1 relative z-10 italic">
                tap to open
              </span>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Modal */}
      <AnimatePresence>
        {modal.open && modal.card && (
          <motion.div
            className="fixed inset-0 z-[200] flex items-center justify-center
                       modal-backdrop bg-text-dark/35 px-5"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={closeModal}
          >
            <motion.div
              className="bg-warm-white rounded-3xl p-8 sm:p-10 max-w-md w-full
                         text-center shadow-[0_24px_80px_rgba(61,42,46,0.28)]
                         relative overflow-hidden"
              initial={{ scale: 0.75, y: 30, opacity: 0 }}
              animate={{ scale: 1, y: 0, opacity: 1 }}
              exit={{ scale: 0.85, y: 20, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 300, damping: 22 }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Top shimmer */}
              <span
                className="absolute top-0 left-0 right-0 h-px"
                style={{ background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.9), transparent)' }}
              />

              <span className="text-4xl block mb-3">{modal.card.icon}</span>

              <h3 className="font-display text-rose-deep text-2xl sm:text-3xl mb-4">
                {modal.card.modalTitle}
              </h3>

              <div className="deco-line mb-4" />

              <p className="font-serif text-lg sm:text-xl italic text-text-mid leading-relaxed">
                {modal.card.modalBody}
              </p>

              <motion.button
                className="mt-7 px-8 py-3 rounded-full bg-gradient-to-br
                           from-rose to-rose-deep text-white font-display text-lg
                           shadow-rose btn-ripple cursor-pointer border-none"
                onClick={closeModal}
                whileHover={{ scale: 1.05, y: -2 }}
                whileTap={{ scale: 0.95 }}
              >
                Close ♡
              </motion.button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
