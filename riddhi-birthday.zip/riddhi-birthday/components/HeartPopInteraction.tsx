'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';

interface HeartReveal {
  emoji: string;
  text: string;
}

interface HeartPopInteractionProps {
  hearts: HeartReveal[];
  subtitle?: string;
}

interface BurstParticle {
  id: number;
  angle: number;
  distance: number;
}

function HeartBurst({ active }: { active: boolean }) {
  const particles: BurstParticle[] = Array.from({ length: 8 }, (_, i) => ({
    id: i,
    angle: (i / 8) * 360,
    distance: 28,
  }));

  return (
    <AnimatePresence>
      {active && particles.map((p) => {
        const rad = (p.angle * Math.PI) / 180;
        const x   = Math.cos(rad) * p.distance;
        const y   = Math.sin(rad) * p.distance;
        return (
          <motion.span
            key={p.id}
            className="absolute top-1/2 left-1/2 w-1.5 h-1.5 rounded-full bg-rose-deep pointer-events-none"
            initial={{ x: 0, y: 0, opacity: 1, scale: 1 }}
            animate={{ x, y, opacity: 0, scale: 0.3 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.45, ease: 'easeOut' }}
            style={{ translateX: '-50%', translateY: '-50%' }}
          />
        );
      })}
    </AnimatePresence>
  );
}

export function HeartPopInteraction({ hearts, subtitle }: HeartPopInteractionProps) {
  const [popped, setPopped]    = useState<Set<number>>(new Set());
  const [revealed, setRevealed] = useState<number | null>(null);
  const [bursting, setBursting] = useState<number | null>(null);

  const handlePop = (index: number) => {
    if (popped.has(index)) return;

    setBursting(index);
    setTimeout(() => setBursting(null), 500);
    setPopped((prev) => new Set(prev).add(index));
    setRevealed(index);
  };

  const allPopped = popped.size === hearts.length;

  return (
    <div className="flex flex-col items-center gap-6 w-full">
      {subtitle && (
        <motion.p
          className="font-body text-mauve text-sm tracking-widest uppercase"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          {subtitle}
        </motion.p>
      )}

      {/* Heart Grid */}
      <div className="grid grid-cols-4 gap-4 sm:gap-6">
        {hearts.map((heart, i) => {
          const isPopped  = popped.has(i);
          const isBursting = bursting === i;

          return (
            <div key={i} className="flex flex-col items-center gap-2">
              <motion.button
                onClick={(e) => { e.stopPropagation(); handlePop(i); }}
                className={cn(
                  'relative w-16 h-16 sm:w-20 sm:h-20 rounded-full border-none',
                  'flex items-center justify-center text-2xl sm:text-3xl',
                  'heart-3d cursor-pointer',
                  isPopped
                    ? 'bg-gradient-to-br from-rose-deep to-[#7B2D3F] shadow-rose-lg popped'
                    : 'bg-gradient-to-br from-blush to-rose shadow-rose',
                )}
                whileHover={!isPopped ? { y: -5, scale: 1.1 } : undefined}
                whileTap={{ scale: 0.88 }}
                animate={isPopped ? { scale: [1, 1.2, 1] } : {}}
                transition={{ duration: 0.4 }}
                aria-label={`Heart ${i + 1}`}
              >
                {/* Shine overlay */}
                <span
                  className="absolute inset-1 rounded-full pointer-events-none"
                  style={{
                    background: 'linear-gradient(135deg, rgba(255,255,255,0.38) 0%, transparent 60%)',
                  }}
                />

                {/* Burst particles */}
                <HeartBurst active={isBursting} />

                {/* Icon */}
                <span className="relative z-10 select-none">
                  {isPopped ? '💝' : heart.emoji}
                </span>
              </motion.button>
            </div>
          );
        })}
      </div>

      {/* Reveal text */}
      <AnimatePresence mode="wait">
        {revealed !== null && (
          <motion.div
            key={revealed}
            className="glass-card px-6 py-4 text-center max-w-xs"
            initial={{ opacity: 0, scale: 0.85, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9 }}
            transition={{ duration: 0.45, ease: [0.34, 1.56, 0.64, 1] }}
          >
            <p className="font-serif text-xl sm:text-2xl italic text-text-mid">
              {hearts[revealed].text}
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* All popped celebration */}
      <AnimatePresence>
        {allPopped && (
          <motion.p
            className="font-display text-rose text-xl sm:text-2xl text-center"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, ease: [0.34, 1.56, 0.64, 1] }}
          >
            You found them all, Kammoji 🌷
          </motion.p>
        )}
      </AnimatePresence>
    </div>
  );
}
