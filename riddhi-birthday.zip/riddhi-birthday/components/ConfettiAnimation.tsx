'use client';

import { useEffect } from 'react';

interface ConfettiAnimationProps {
  trigger: boolean;
  loop?: boolean;
}

export function ConfettiAnimation({ trigger, loop = false }: ConfettiAnimationProps) {
  useEffect(() => {
    if (!trigger) return;

    let rafId: ReturnType<typeof setTimeout>;
    let mounted = true;

    (async () => {
      const confetti = (await import('canvas-confetti')).default;

      const fire = () => {
        if (!mounted) return;
        confetti({
          particleCount: 60,
          spread: 80,
          origin: { x: Math.random(), y: 0.55 },
          colors: ['#C4687A', '#F2D7D9', '#E8D5E8', '#C9919E', '#FDF6F0', '#A84E62'],
          shapes: ['circle', 'square'],
          scalar: 0.9,
          gravity: 0.8,
          drift: (Math.random() - 0.5) * 0.4,
        });
      };

      fire();
      fire();

      if (loop) {
        const interval = setInterval(() => {
          if (!mounted) { clearInterval(interval); return; }
          fire();
        }, 2200);
        return () => { clearInterval(interval); mounted = false; };
      }
    })();

    return () => { mounted = false; clearTimeout(rafId); };
  }, [trigger, loop]);

  return null;
}
