'use client';

import { useEffect, useRef } from 'react';
import { randomBetween } from '@/lib/utils';

const SYMBOLS = ['♡', '✦', '✧', '⋆', '❀', '♡', '✦'];

interface Particle {
  id: number;
  symbol: string;
  left: number;
  animDuration: number;
  animDelay: number;
  fontSize: number;
  drift: number;
  opacity: number;
}

function generateParticles(count: number): Particle[] {
  return Array.from({ length: count }, (_, i) => ({
    id:           i,
    symbol:       SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
    left:         randomBetween(2, 98),
    animDuration: randomBetween(8, 18),
    animDelay:    randomBetween(0, 12),
    fontSize:     randomBetween(10, 22),
    drift:        randomBetween(-40, 40),
    opacity:      randomBetween(0.3, 0.75),
  }));
}

export function FloatingParticles({ count = 18 }: { count?: number }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const particlesRef = useRef<Particle[]>(generateParticles(count));

  useEffect(() => {
    // Regenerate on mount for variety
    particlesRef.current = generateParticles(count);
    if (!containerRef.current) return;
    const el = containerRef.current;

    particlesRef.current.forEach((p) => {
      const span = document.createElement('span');
      span.textContent = p.symbol;
      span.style.cssText = `
        position: absolute;
        left: ${p.left}%;
        bottom: -20px;
        font-size: ${p.fontSize}px;
        color: #C4687A;
        opacity: ${p.opacity};
        animation: particleRise ${p.animDuration}s ${p.animDelay}s linear infinite;
        --drift: ${p.drift}px;
        pointer-events: none;
        will-change: transform;
      `;
      el.appendChild(span);
    });

    return () => {
      while (el.firstChild) el.removeChild(el.firstChild);
    };
  }, [count]);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 overflow-hidden pointer-events-none"
      style={{ zIndex: 2 }}
      aria-hidden="true"
    />
  );
}
