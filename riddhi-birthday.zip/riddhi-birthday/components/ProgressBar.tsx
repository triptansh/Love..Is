'use client';

import { motion } from 'framer-motion';

// ── Progress Bar ───────────────────────────────────────────
interface ProgressBarProps {
  progress: number;
  current: number;
  total: number;
}

export function ProgressBar({ progress, current, total }: ProgressBarProps) {
  return (
    <>
      {/* Bottom progress line */}
      <div className="fixed bottom-0 left-0 right-0 h-[3px] bg-rose/10 z-50">
        <motion.div
          className="h-full rounded-full"
          style={{
            background: 'linear-gradient(90deg, #F2D7D9, #C4687A, #A84E62)',
          }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.55, ease: [0.4, 0, 0.2, 1] }}
        />
      </div>

      {/* Slide counter */}
      <div
        className="fixed bottom-4 right-4 z-50 slide-number-badge"
        aria-live="polite"
      >
        {current} / {total}
      </div>

      {/* Tap hint — shows only on slide 1 */}
      {current === 1 && (
        <motion.div
          className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 pointer-events-none
                     font-body text-mauve text-xs tracking-widest"
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: [0, 0.7, 0.7, 0] }}
          transition={{ duration: 3.5, delay: 2.5, times: [0, 0.1, 0.8, 1] }}
        >
          tap anywhere to continue ↓
        </motion.div>
      )}
    </>
  );
}

// ── Audio Controller ───────────────────────────────────────
interface AudioControllerProps {
  isPlaying: boolean;
  isMuted:   boolean;
  onToggle:  () => void;
  onMute:    () => void;
}

export function AudioController({
  isPlaying,
  isMuted,
  onToggle,
  onMute,
}: AudioControllerProps) {
  return (
    <div className="fixed top-4 right-4 z-50 flex items-center gap-2">
      {/* Play/Pause */}
      <motion.button
        onClick={(e) => { e.stopPropagation(); onToggle(); }}
        className="w-9 h-9 rounded-full glass-card flex items-center justify-center
                   text-rose text-base border border-rose/20 cursor-pointer
                   hover:scale-110 active:scale-95 transition-transform"
        whileTap={{ scale: 0.88 }}
        title={isPlaying ? 'Pause music' : 'Play music'}
        aria-label={isPlaying ? 'Pause music' : 'Play music'}
      >
        {isPlaying ? '⏸' : '♪'}
      </motion.button>

      {/* Mute */}
      {isPlaying && (
        <motion.button
          onClick={(e) => { e.stopPropagation(); onMute(); }}
          className="w-9 h-9 rounded-full glass-card flex items-center justify-center
                     text-rose text-sm border border-rose/20 cursor-pointer
                     hover:scale-110 active:scale-95 transition-transform"
          initial={{ opacity: 0, scale: 0.7 }}
          animate={{ opacity: 1, scale: 1 }}
          whileTap={{ scale: 0.88 }}
          title={isMuted ? 'Unmute' : 'Mute'}
          aria-label={isMuted ? 'Unmute' : 'Mute'}
        >
          {isMuted ? '🔇' : '🔊'}
        </motion.button>
      )}
    </div>
  );
}

// ── Back Button (shows after slide 1) ─────────────────────
interface BackButtonProps {
  onBack:  () => void;
  visible: boolean;
}

export function BackButton({ onBack, visible }: BackButtonProps) {
  if (!visible) return null;
  return (
    <motion.button
      onClick={(e) => { e.stopPropagation(); onBack(); }}
      className="fixed top-4 left-4 z-50 w-9 h-9 rounded-full glass-card
                 flex items-center justify-center text-rose text-sm
                 border border-rose/20 cursor-pointer
                 hover:scale-110 active:scale-95 transition-transform"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      whileTap={{ scale: 0.88 }}
      title="Previous slide"
      aria-label="Previous slide"
    >
      ←
    </motion.button>
  );
}
