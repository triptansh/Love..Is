'use client';

import { useState, useRef, useCallback, useEffect } from 'react';
import { motion, useMotionValue, useSpring } from 'framer-motion';
import { clamp } from '@/lib/utils';

interface MovingButtonProps {
  label: string;
  onEscapeClick?: () => void;
  className?: string;
}

export function MovingButton({ label, onEscapeClick, className }: MovingButtonProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const springX = useSpring(x, { stiffness: 200, damping: 18 });
  const springY = useSpring(y, { stiffness: 200, damping: 18 });

  // Track mouse/touch proximity
  const handleProximity = useCallback((clientX: number, clientY: number) => {
    const btn = containerRef.current;
    if (!btn) return;

    const rect   = btn.getBoundingClientRect();
    const btnCx  = rect.left + rect.width  / 2;
    const btnCy  = rect.top  + rect.height / 2;
    const dx     = clientX - btnCx;
    const dy     = clientY - btnCy;
    const dist   = Math.sqrt(dx * dx + dy * dy);
    const radius = 100;

    if (dist < radius) {
      const force   = (radius - dist) / radius;
      const moveX   = -(dx / dist) * force * 80;
      const moveY   = -(dy / dist) * force * 80;

      // Clamp within viewport
      const currentX = x.get();
      const currentY = y.get();
      const maxDrift = 120;

      x.set(clamp(currentX + moveX * 0.35, -maxDrift, maxDrift));
      y.set(clamp(currentY + moveY * 0.35, -maxDrift, maxDrift));
    }
  }, [x, y]);

  useEffect(() => {
    const onMouseMove = (e: MouseEvent) => handleProximity(e.clientX, e.clientY);
    const onTouchMove = (e: TouchEvent) => {
      const t = e.touches[0];
      if (t) handleProximity(t.clientX, t.clientY);
    };

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('touchmove', onTouchMove, { passive: true });
    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('touchmove', onTouchMove);
    };
  }, [handleProximity]);

  return (
    <div ref={containerRef} className="relative inline-block">
      <motion.button
        style={{ x: springX, y: springY }}
        onClick={(e) => { e.stopPropagation(); onEscapeClick?.(); }}
        className={className}
        whileTap={{ scale: 0.92 }}
      >
        {label}
      </motion.button>
    </div>
  );
}
