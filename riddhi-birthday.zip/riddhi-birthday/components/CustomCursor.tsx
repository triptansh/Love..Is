'use client';

import { useEffect, useRef } from 'react';

export function CustomCursor() {
  const dotRef  = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Only on desktop
    if (window.matchMedia('(hover: none)').matches) return;

    const dot  = dotRef.current;
    const ring = ringRef.current;
    if (!dot || !ring) return;

    let dotX = 0, dotY = 0;
    let ringX = 0, ringY = 0;
    let raf: number;

    const onMove = (e: MouseEvent) => {
      dotX = e.clientX;
      dotY = e.clientY;
    };

    const animate = () => {
      // Ring follows with lag
      ringX += (dotX - ringX) * 0.12;
      ringY += (dotY - ringY) * 0.12;

      dot.style.left  = `${dotX}px`;
      dot.style.top   = `${dotY}px`;
      ring.style.left = `${ringX}px`;
      ring.style.top  = `${ringY}px`;

      raf = requestAnimationFrame(animate);
    };

    const onEnterLink = () => ring.classList.add('hover');
    const onLeaveLink = () => ring.classList.remove('hover');

    document.addEventListener('mousemove', onMove);
    document.querySelectorAll('a, button, [role="button"]').forEach((el) => {
      el.addEventListener('mouseenter', onEnterLink);
      el.addEventListener('mouseleave', onLeaveLink);
    });

    raf = requestAnimationFrame(animate);

    // Show cursors
    if (dot)  dot.style.display  = 'block';
    if (ring) ring.style.display = 'block';

    return () => {
      cancelAnimationFrame(raf);
      document.removeEventListener('mousemove', onMove);
    };
  }, []);

  return (
    <>
      <div
        ref={dotRef}
        className="cursor cursor-dot hidden fixed pointer-events-none z-[9999]"
        aria-hidden="true"
      />
      <div
        ref={ringRef}
        className="cursor cursor-ring hidden fixed pointer-events-none z-[9998]"
        aria-hidden="true"
      />
    </>
  );
}
