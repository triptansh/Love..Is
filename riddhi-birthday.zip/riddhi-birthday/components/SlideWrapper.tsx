'use client';

import { ReactNode } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface SlideWrapperProps {
  children: ReactNode;
  slideKey: number;
  direction: 'forward' | 'back';
  onAdvance?: () => void;
}

const variants = {
  enter: (dir: string) => ({
    opacity: 0,
    y:    dir === 'forward' ?  40 : -40,
    scale: 0.97,
    filter: 'blur(4px)',
  }),
  center: {
    opacity: 1,
    y: 0,
    scale: 1,
    filter: 'blur(0px)',
  },
  exit: (dir: string) => ({
    opacity: 0,
    y:    dir === 'forward' ? -40 :  40,
    scale: 1.03,
    filter: 'blur(4px)',
  }),
};

export function SlideWrapper({
  children,
  slideKey,
  direction,
  onAdvance,
}: SlideWrapperProps) {
  return (
    <AnimatePresence mode="wait" custom={direction}>
      <motion.div
        key={slideKey}
        custom={direction}
        variants={variants}
        initial="enter"
        animate="center"
        exit="exit"
        transition={{
          duration: 0.75,
          ease: [0.4, 0, 0.2, 1],
        }}
        className="absolute inset-0 flex flex-col items-center justify-center px-5 py-8"
        onClick={onAdvance}
        style={{ zIndex: 10 }}
      >
        {children}
      </motion.div>
    </AnimatePresence>
  );
}
