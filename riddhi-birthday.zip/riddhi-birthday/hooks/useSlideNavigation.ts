'use client';

import { useState, useCallback, useEffect } from 'react';
import { SLIDES } from '@/data/slides';

export function useSlideNavigation() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection]       = useState<'forward' | 'back'>('forward');
  const total = SLIDES.length;

  const goNext = useCallback(() => {
    setDirection('forward');
    setCurrentIndex((i) => Math.min(i + 1, total - 1));
  }, [total]);

  const goPrev = useCallback(() => {
    setDirection('back');
    setCurrentIndex((i) => Math.max(i - 1, 0));
  }, []);

  const goTo = useCallback((index: number) => {
    setDirection(index > currentIndex ? 'forward' : 'back');
    setCurrentIndex(Math.max(0, Math.min(index, total - 1)));
  }, [currentIndex, total]);

  // Keyboard navigation
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'ArrowDown' || e.key === ' ') {
        e.preventDefault();
        goNext();
      }
      if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
        e.preventDefault();
        goPrev();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [goNext, goPrev]);

  return {
    currentIndex,
    currentSlide: SLIDES[currentIndex],
    direction,
    total,
    isFirst: currentIndex === 0,
    isLast:  currentIndex === total - 1,
    progress: ((currentIndex + 1) / total) * 100,
    goNext,
    goPrev,
    goTo,
  };
}
