'use client';

import { useState, useEffect, useRef, useCallback } from 'react';

export function useAudio(src: string) {
  const howlRef = useRef<InstanceType<typeof import('howler').Howl> | null>(null);
  const [isPlaying, setIsPlaying]   = useState(false);
  const [isMuted,   setIsMuted]     = useState(false);
  const [isReady,   setIsReady]     = useState(false);
  const [hasError,  setHasError]    = useState(false);

  useEffect(() => {
    let mounted = true;

    (async () => {
      try {
        const { Howl } = await import('howler');
        const howl = new Howl({
          src:    [src],
          loop:   true,
          volume: 0,
          html5:  true,
          preload: true,
          onload: () => {
            if (mounted) setIsReady(true);
          },
          onloaderror: () => {
            if (mounted) setHasError(true);
          },
        });
        if (mounted) howlRef.current = howl;
      } catch {
        if (mounted) setHasError(true);
      }
    })();

    return () => {
      mounted = false;
      howlRef.current?.unload();
    };
  }, [src]);

  const play = useCallback(() => {
    if (!howlRef.current || hasError) return;
    const h = howlRef.current;
    if (!h.playing()) h.play();
    h.fade(h.volume(), 0.35, 1800);
    setIsPlaying(true);
  }, [hasError]);

  const pause = useCallback(() => {
    if (!howlRef.current) return;
    const h = howlRef.current;
    h.fade(h.volume(), 0, 800);
    setTimeout(() => h.pause(), 820);
    setIsPlaying(false);
  }, []);

  const toggle = useCallback(() => {
    isPlaying ? pause() : play();
  }, [isPlaying, play, pause]);

  const mute = useCallback(() => {
    if (!howlRef.current) return;
    howlRef.current.mute(true);
    setIsMuted(true);
  }, []);

  const unmute = useCallback(() => {
    if (!howlRef.current) return;
    howlRef.current.mute(false);
    setIsMuted(false);
  }, []);

  const toggleMute = useCallback(() => {
    isMuted ? unmute() : mute();
  }, [isMuted, mute, unmute]);

  return { isPlaying, isMuted, isReady, hasError, play, pause, toggle, toggleMute };
}
