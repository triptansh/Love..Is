// ============================================================
//  SLIDE CONTENT CONFIGURATION
//  Edit all slide text content here — no component changes needed.
// ============================================================

export type SlideType =
  | 'hero'
  | 'floating-names'
  | 'poetic-lines'
  | 'tap-reveal'
  | 'hindi-poem'
  | 'confetti-celebration'
  | 'heart-pop'
  | 'choice-buttons'
  | 'memory-cards'
  | 'ego-slide'
  | 'court-of-love'
  | 'simple-card';

export interface FloatingName {
  name: string;
  meaning: string;
}

export interface RevealLine {
  text: string;
}

export interface HeartReveal {
  emoji: string;
  text: string;
}

export interface ChoiceOption {
  label: string;
}

export interface MemoryCard {
  icon: string;
  label: string;
  modalTitle: string;
  modalBody: string;
}

export interface SlideConfig {
  id: number;
  type: SlideType;
  // Generic text fields
  title?: string;
  subtitle?: string;
  caption?: string;
  lines?: string[];
  // Hero
  ctaLabel?: string;
  // Floating names
  floatingNames?: FloatingName[];
  // Tap-reveal lines
  revealLines?: RevealLine[];
  revealCta?: string;
  // Heart pop
  heartReveals?: HeartReveal[];
  // Choice buttons
  choiceQuestion?: string;
  choiceOptions?: ChoiceOption[];
  choiceResponse?: string;
  // Memory cards
  memoryCards?: MemoryCard[];
  // Background color accent variant
  accent?: 'default' | 'warm' | 'lavender';
}

export const SLIDES: SlideConfig[] = [
  // ── Slide 1 ──────────────────────────────────────────────
  {
    id: 1,
    type: 'hero',
    title: 'Happy Birthday, Riddhi 🌷',
    subtitle: 'Today is about celebrating you.',
    ctaLabel: "Enter My Kammoji's World",
  },

  // ── Slide 2 ──────────────────────────────────────────────
  {
    id: 2,
    type: 'floating-names',
    caption: 'Some names feel like peace.',
    floatingNames: [
      { name: 'Riddhi',  meaning: 'growth.' },
      { name: 'Advika',  meaning: 'unique.' },
      { name: 'Kammoji', meaning: 'mine, softly.' },
    ],
  },

  // ── Slide 3 ──────────────────────────────────────────────
  {
    id: 3,
    type: 'poetic-lines',
    lines: [
      'You deserve a love that feels safe.',
      'You deserve someone who shows up.',
      'You deserve someone who understands.',
    ],
    caption: 'I am learning. And I am here.',
  },

  // ── Slide 4 ──────────────────────────────────────────────
  {
    id: 4,
    type: 'tap-reveal',
    revealCta: 'Tap to see what I love about you',
    revealLines: [
      { text: 'The way you feel deeply.' },
      { text: 'The way you care too much.' },
      { text: 'The way your voice softens when emotional.' },
      { text: 'The way you just want reassurance.' },
    ],
  },

  // ── Slide 5 ──────────────────────────────────────────────
  {
    id: 5,
    type: 'hindi-poem',
    lines: [
      'Tumhari narazgi bhi tumhari tarah pyaari hai,',
      'kyunki usmein bhi sirf ehsaas hota hai.',
    ],
    caption: 'I never thought you were too much.',
  },

  // ── Slide 6 ──────────────────────────────────────────────
  {
    id: 6,
    type: 'poetic-lines',
    lines: [
      'When you get emotional,',
      "I don't go quiet because I don't care.",
      "I go quiet because I'm scared of hurting you.",
      'But I am learning to hold better.',
    ],
  },

  // ── Slide 7 ──────────────────────────────────────────────
  {
    id: 7,
    type: 'confetti-celebration',
    title: 'No heavy talks today.',
    lines: ['Just softness.', "Because Kammoji's birthday deserves peace."],
  },

  // ── Slide 8 ──────────────────────────────────────────────
  {
    id: 8,
    type: 'poetic-lines',
    lines: [
      'You were vulnerable.',
      'I should have held you better.',
      'Not with space.',
      'With presence.',
    ],
  },

  // ── Slide 9 ──────────────────────────────────────────────
  {
    id: 9,
    type: 'heart-pop',
    subtitle: 'Tap the hearts ♡',
    heartReveals: [
      { emoji: '💕', text: 'Your smile is dangerous.' },
      { emoji: '💖', text: 'Your anger is dramatic but adorable.' },
      { emoji: '💗', text: 'Your heart is rare.' },
      { emoji: '💝', text: 'Your love is deep.' },
    ],
  },

  // ── Slide 10 ─────────────────────────────────────────────
  {
    id: 10,
    type: 'poetic-lines',
    lines: [
      'I am not numb.',
      'I express differently.',
      'But I feel deeply.',
      'Especially for you.',
    ],
  },

  // ── Slide 11 ─────────────────────────────────────────────
  {
    id: 11,
    type: 'choice-buttons',
    choiceQuestion: 'If upset, what helps?',
    choiceOptions: [
      { label: 'Hold me.' },
      { label: 'Reassure me.' },
      { label: 'Fight for me.' },
      { label: 'All of the above.' },
    ],
    choiceResponse: "I'm learning to do all of it.",
  },

  // ── Slide 12 ─────────────────────────────────────────────
  {
    id: 12,
    type: 'hindi-poem',
    title: 'Is saal, meri Kammoji,',
    lines: [
      'har darr pakadunga,',
      'har aansu sambhalunga,',
      "har overthinking pe kahunga —",
      "'Main yahin hoon.'",
    ],
  },

  // ── Slide 13 ─────────────────────────────────────────────
  {
    id: 13,
    type: 'hindi-poem',
    lines: [
      'Tum jazbaat ho gehre samandar jaise,',
      'main seekh raha hoon tairna tumhare sahare jaise.',
      'Tum lafzon mein dhal jaati ho aasani se,',
      'main dhadkanon mein likhta hoon tumhe khamoshi se.',
    ],
    caption: 'Bas tareeke alag the.',
  },

  // ── Slide 14 ─────────────────────────────────────────────
  {
    id: 14,
    type: 'memory-cards',
    subtitle: 'Our little moments ✨',
    memoryCards: [
      {
        icon: '😂',
        label: 'First Laugh',
        modalTitle: 'When We First Laughed',
        modalBody:
          'That moment you laughed — really laughed — and I realised this was someone I never wanted to stop making smile. It was warm. It was easy. It was us.',
      },
      {
        icon: '💢',
        label: 'First Fight',
        modalTitle: 'When We First Fought',
        modalBody:
          "It was clumsy. It hurt. But it also showed me how much you feel — and how much I was willing to sit in discomfort just to come back to you. That fight taught me something.",
      },
      {
        icon: '💡',
        label: 'First Realisation',
        modalTitle: 'When I Knew I Cared',
        modalBody:
          'There was a moment — quiet, ordinary — where it hit me. I was thinking about you and I wasn\'t trying to stop. That\'s when I knew: this was something I wanted to protect.',
      },
    ],
  },

  // ── Slide 15 ─────────────────────────────────────────────
  {
    id: 15,
    type: 'poetic-lines',
    lines: [
      "You didn't lose me.",
      "I just didn't fight properly.",
      "That's on me.",
    ],
  },

  // ── Slide 16 ─────────────────────────────────────────────
  {
    id: 16,
    type: 'ego-slide',
    title: 'Kammoji > My Ego',
    caption: 'Always.',
  },

  // ── Slide 17 ─────────────────────────────────────────────
  {
    id: 17,
    type: 'hindi-poem',
    lines: [
      'Kabhi kabhi, meri Awasthi ji,',
      'baat lafzon ki nahi hoti,',
      'bas thoda sa zor se pakadne ki hoti hai.',
      'Aur haan…',
      'pakadne mein der meri thi.',
    ],
  },

  // ── Slide 18 ─────────────────────────────────────────────
  {
    id: 18,
    type: 'hindi-poem',
    lines: [
      'Tum ho roshni subah ki,',
      'tum ho shaam ka sukoon,',
      'tum ho dua jo maangi nahi,',
      'phir bhi mil gayi khoobsurat roop mein.',
    ],
    caption: 'Riddhi, tum poori ho.',
    accent: 'lavender',
  },

  // ── Slide 19 ─────────────────────────────────────────────
  {
    id: 19,
    type: 'hindi-poem',
    lines: [
      'Agar pyaar ek kahani hai,',
      'toh meri har line mein tum ho.',
      'Agar saans ek wajah se chalti hai,',
      'toh meri har wajah mein tum ho.',
      'Naraz ho toh bhi tum ho,',
      'khush ho toh bhi tum ho.',
      'Meri Panditain,',
      'tum meri niyat ho.',
    ],
  },

  // ── Slide 20 ─────────────────────────────────────────────
  {
    id: 20,
    type: 'court-of-love',
    title: 'The Official Court of Love ⚖️',
    lines: [
      'Toh meri Panditain ji,',
      'kya apne Pandit ji ko maafi milegi?',
    ],
  },
];
