'use client';

import { useCallback, useEffect, useRef } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { useSlideNavigation }        from '@/hooks/useSlideNavigation';
import { useAudio }                  from '@/hooks/useAudio';
import { SlideWrapper }              from '@/components/SlideWrapper';
import { SlideFactory }              from '@/components/slides/SlideFactory';
import { FloatingParticles }         from '@/components/FloatingParticles';
import { ProgressBar, AudioController, BackButton } from '@/components/ProgressBar';
import { CustomCursor }              from '@/components/CustomCursor';

// Slides with types that should NOT advance on background tap
const NON_TAP_ADVANCE_TYPES = new Set([
  'hero',        // Has its own CTA button
  'tap-reveal',  // Manages its own tap
  'heart-pop',
  'choice-buttons',
  'memory-cards',
  'court-of-love',
]);

export default function BirthdayPage() {
  const nav   = useSlideNavigation();
  const audio = useAudio('/audio/piano.mp3'); // Place your audio file here
  const audioStarted = useRef(false);

  // Unlock audio on first interaction
  const handleFirstInteraction = useCallback(() => {
    if (!audioStarted.current) {
      audioStarted.current = true;
      audio.play();
    }
  }, [audio]);

  // Handle slide advance on background click/tap
  const handleSlideClick = useCallback(() => {
    handleFirstInteraction();
    if (!NON_TAP_ADVANCE_TYPES.has(nav.currentSlide.type)) {
      nav.goNext();
    }
  }, [handleFirstInteraction, nav]);

  // Touch swipe support
  const touchStartY = useRef(0);
  const onTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
  };
  const onTouchEnd = (e: React.TouchEvent) => {
    const dy = touchStartY.current - e.changedTouches[0].clientY;
    if (Math.abs(dy) > 50) {
      if (dy > 0) nav.goNext();
      else        nav.goPrev();
    }
  };

  return (
    <main
      className="relative w-full h-full overflow-hidden"
      onTouchStart={onTouchStart}
      onTouchEnd={onTouchEnd}
    >
      {/* ── Animated Background ── */}
      <div className="bg-animated fixed inset-0 z-0" />

      {/* ── Watercolor heart texture overlay ── */}
      <div className="heart-texture" />

      {/* ── Particles ── */}
      <FloatingParticles count={20} />

      {/* ── Custom Cursor ── */}
      <CustomCursor />

      {/* ── Slide Canvas ── */}
      <div
        className="slide-container"
        onClick={handleSlideClick}
        role="main"
        aria-label="Birthday experience"
      >
        <AnimatePresence mode="wait" custom={nav.direction}>
          <SlideWrapper
            key={nav.currentIndex}
            slideKey={nav.currentIndex}
            direction={nav.direction}
            onAdvance={
              NON_TAP_ADVANCE_TYPES.has(nav.currentSlide.type)
                ? undefined
                : nav.goNext
            }
          >
            <SlideFactory
              slide={nav.currentSlide}
              onAdvance={nav.goNext}
            />
          </SlideWrapper>
        </AnimatePresence>
      </div>

      {/* ── UI Chrome ── */}
      <ProgressBar
        progress={nav.progress}
        current={nav.currentIndex + 1}
        total={nav.total}
      />

      <AudioController
        isPlaying={audio.isPlaying}
        isMuted={audio.isMuted}
        onToggle={() => { handleFirstInteraction(); audio.toggle(); }}
        onMute={audio.toggleMute}
      />

      <BackButton
        onBack={nav.goPrev}
        visible={nav.currentIndex > 0}
      />

      {/* ── Skip to end button (accessibility) ── */}
      <button
        className="sr-only focus:not-sr-only focus:fixed focus:bottom-10 focus:left-4
                   focus:z-50 focus:px-4 focus:py-2 focus:bg-rose focus:text-white
                   focus:rounded-full focus:text-sm"
        onClick={() => nav.goTo(nav.total - 1)}
      >
        Skip to end
      </button>
    </main>
  );
}
